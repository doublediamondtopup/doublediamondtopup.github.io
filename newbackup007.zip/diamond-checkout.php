<?php
if(@$_POST['submit']){
  $amount=@$_REQUEST['amt'];
  $link="upi://pay?pa=merchant.augp@aubank&amp;pn=TOPUP&amp;tn=OrderID:4562&amp;am=".$amount."&amp;cu=INR";
 header("Location: ".$link, true, 301);  
}else{
  header("Location: diamonds.php");
}
?>