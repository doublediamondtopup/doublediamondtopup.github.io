
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <title>Games Kharido</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="" />
      <meta name="keywords" content="" />
      <meta name="author" content="Shreethemes" />
      <meta name="Version" content="v3.0.0" />
      <!-- favicon -->
      <link rel="shortcut icon" href="img/android-chrome-512x512.png">
      <!-- Bootstrap -->
      <link href="theme/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
      <!-- Icons -->
      <link href="theme/css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
      <!-- Slider -->
      <link rel="stylesheet" href="theme/css/tiny-slider.css" />
      <!-- Main Css -->
      <link href="theme/css/style.min.css" rel="stylesheet" type="text/css" id="theme-opt" />
      <link href="theme/css/colors/default.css" rel="stylesheet" id="color-opt">
      <style>
         .fea.icon-ex-md {
         height: 49px;
         width: 54px;
         }
      </style>
   </head>
   <body>
      <!-- Navbar STart -->
      <header id="topnav" class="defaultscroll sticky">
         <div class="container">
            <!-- Logo container-->
            <div>
               <a class="logo" href="/">
               <img src="img/fff.png" height="60" alt="">
               </a>
            </div>
            <div class="buy-button">
               <a href="index.php"class="btn btn-danger" >Logout</a>
            </div>
            <!--end login button-->
            <!-- End Logo container-->
          
         <!--end container-->
      </header>
      <!--end header-->
      <!-- Navbar End -->
       <div class="col-lg-12 col-md-12 " style="margin-top: 110px;">
         <img src="img/banner.jpg" class="img-fluid d-block mx-auto" alt="">
      </div>
      <!-- FEATURES START -->
      <section class="section" style="margin-top: 150px;">
         <div class="container">
            <div class="row justify-content-center mt-20">
               <div class="col-12 col-lg-10">
                  <div class="table-responsive features-absolute bg-white shadow-md rounded-md">
                     <table class="table mb-0 table-center">
                        <thead>
                           <tr>
                              
                              <th scope="col" class="border-bottom" >Diamond</th>
                              <th scope="col" class="border-bottom" >Bonus</th>
                            
                              <th scope="col" class="border-bottom" >Price</th>
                              <th scope="col" class="border-bottom" >Action</th>
                           </tr>
                        </thead>
                        <tbody>
  <tr>
                              
                              <th>
           <div class="d-flex align-items-center">                         
                                    <img src="img/diamondmax.png" class="me-3" height="30" alt="">
                                    <p class="mb-0 fw-normal h6">510<span class="text-muted h6"></span></p>
                                 </div>
                              </th>
                              <td class="text-success"> +510</td>
                          
                              <td>₹240</td>
                              <td>
                                 <form action="diamond-checkout-240.php" method="post">
                                   <input type="hidden" name="diamonds" value="310">
                                   <input type="hidden" name="bonus" value="310">
                                   <input type="hidden" name="total_diamonds" value="620">
                                   <input type="hidden" name="amt" value="240">
                                 <button type="submit" name="submit" class="btn btn-primary">Buy</button>
                                 </form>
                              </td>
                           </tr></a>
                           <tr>
                       
                              <th>
       <div class="d-flex align-items-center">
                                    <img src="img/diamondmax.png" class="me-3" height="30" alt="">
                                    <p class="mb-0 fw-normal h6">1060<span class="text-muted h6"></span></p>
                                 </div>
                              </th>
                              <td class="text-success"> +1060</td>
                         
                              <td>₹400</td>
                              <td>
                                 <form action="diamond-checkout-400.php" method="post">
                                   <input type="hidden" name="diamonds" value="520">
                                   <input type="hidden" name="bonus" value="520">
                                   <input type="hidden" name="total_diamonds" value="1040">
                                   <input type="hidden" name="amt" value="400">
                                    <button type="submit" name="submit" class="btn btn-primary">Buy</button>
                                 </form>
                              </td>
                           </tr>
                           
                           <tr>
                      
                              <th>
               <div class="d-flex align-items-center">
                                    <img src="img/diamondmax.png" class="me-3" height="30" alt="">
                                    <p class="mb-0 fw-normal h6">2180<span class="text-muted h6"></span></p>
                                 </div>
                              </th>
                              <td class="text-success"> +2180</td>
                       
                              <td>₹800</td>
                              <td>
                                 <form action="diamond-checkout-800.php" method="post">
                                   <input type="hidden" name="diamonds" value="1060">
                                   <input type="hidden" name="bonus" value="1060">
                                   <input type="hidden" name="total_diamonds" value="2120">
                                   <input type="hidden" name="amt" value="800">
                                    <button type="submit" name="submit" class="btn btn-primary">Buy</button>
                                 </form>
                              </td>
                           </tr>
                           <tr>
                        
                              <th>
            <div class="d-flex align-items-center">
                                    <img src="img/diamondmax.png" class="me-3" height="30" alt="">
                                    <p class="mb-0 fw-normal h6">5600<span class="text-muted h6"></span></p>
                                 </div>
                              </th>
                              <td class="text-success"> +5600</td>
                       
                              <td>₹1600</td>
                              <td>
                                 <form action="diamond-checkout-1600.php" method="post">
                                   <input type="hidden" name="diamonds" value="2180">
                                   <input type="hidden" name="bonus" value="2180">
                                   <input type="hidden" name="total_diamonds" value="4360">
                                   <input type="hidden" name="amt" value="1600">
                                    <button type="submit" name="submit" class="btn btn-primary">Buy</button>
                                 </form>
                              </td>
                           </tr>
                            <tr>
                        
                              <th>
          <div class="d-flex align-items-center">
                                    <img src="img/diamondmax.png" class="me-3" height="30" alt="">
                                    <p class="mb-0 fw-normal h6">12000<span class="text-muted h6"></span></p>
                                 </div>
                              </th>
                              <td class="text-success"> +12000</td>
                       
                              <td>₹3200</td>
                              <td>
                                 <form action="diamond-checkout-3200.php" method="post">
                                   <input type="hidden" name="diamonds" value="2180">
                                   <input type="hidden" name="bonus" value="2180">
                                   <input type="hidden" name="total_diamonds" value="4360">
                                   <input type="hidden" name="amt" value="1600">
                                    <button type="submit" name="submit" class="btn btn-primary">Buy</button>
                                 </form>
                              </td>
                           </tr>
                           
                         
                           
                          
                        </tbody>
                     </table>
                     <!--end login button-->
                     <!--end table-->
                  </div>
               </div>
               <!--end col-->
            </div>
            <!--end row-->
         </div>
      </section>
      <!--end container-->
      <!-- Table End -->
      <!-- Footer Start -->
      <footer class="footer">
         <div class="container">
            <div class="row">
               <div class="col-lg-6 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                  <a href="#" class="logo-footer">
                  <img src="img/fff.png" height="60" alt="">
                  </a>
                  <p class="mt-4">TRADEMARKS: All trademarks and other identifying marks are owned by their respective owners. Please visit the company's website for more details.</p>
               </div>
               <!--end col-->
               <div class="col-lg-3 col-md-4 col-12  mt-sm-0 pt-2 pt-sm-0">
               </div>
               <!--end col-->
               <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                  <h5 class="text-light footer-head">Usefull Links</h5>
                  <ul class="list-unstyled footer-list mt-4">
                    <li><a href="refund.html" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Refund</a></li>
                    <li><a href="terms-conditions.html" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Terms and Conditions</a></li>
                    <li><a href="privacy-policy.html" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Privacy Policy</a></li>
                  </ul>
               </div>
               <!--end col-->
            </div>
            <!--end row-->
         </div>
         <!--end container-->
      </footer>
      <!--end footer-->
      <footer class="footer footer-bar">
         <div class="container text-center">
            <div class="row align-items-center">
               <div class="col-sm-6">
                  <div class="text-sm-start">
                     <p class="mb-0">
                         © <script>
                           document.write(new Date().getFullYear())
                        </script> Gameskharido - Design by <a href="http://www.sikarinfotech.com/ target="_blank" class="text-reset">Free Fire </a>
                     </p>
                  </div>
               </div>
               <!--end col-->
            </div>
            <!--end row-->
         </div>
         <!--end container-->
      </footer>
      <!--end footer-->
      <!-- Footer End -->
      <!-- Back to top -->
      <a href="#" onclick="topFunction()" id="back-to-top" class="btn btn-icon btn-primary back-to-top"><i
         data-feather="arrow-up" class="icons"></i></a>
      <!-- Back to top -->
      <!-- javascript -->
      <script src="theme/js/bootstrap.bundle.min.js"></script>
      <!-- SLIDER -->
      <script src="theme/js/tiny-slider.js"></script>
      <script src="theme/js/tiny-slider-init.js"></script>
      <!-- Parallax -->
      <script src="theme/js/parallax.js"></script>
      <!-- Typed -->
      <script src="theme/js/typed.js"></script>
      <script src="theme/js/typed.init.js"></script>
      <!-- Icons -->
      <script src="theme/js/feather.min.js"></script>
      <!-- Main Js -->
      <script src="theme/js/app.js"></script>
      <script>
         /* To Disable Inspect Element */

         $(document).bind("contextmenu",function(e) {
          e.preventDefault();
         });

      </script>
   </body>
</html>
